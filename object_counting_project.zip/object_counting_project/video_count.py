import cv2
from ultralytics import YOLO
from collections import defaultdict

# Load YOLO model
model = YOLO("models/yolov8n.pt")

# Load video
cap = cv2.VideoCapture("input/video.mp4")

while cap.isOpened():
    ret, frame = cap.read()
    if not ret:
        break

    # Run YOLO detection (silent)
    results = model(frame, verbose=False)

    # Dictionary to store object counts per frame
    object_counts = defaultdict(int)

    # Process detections
    for r in results:
        for box in r.boxes:
            cls = int(box.cls[0])
            conf = float(box.conf[0])
            class_name = model.names[cls]

            if conf > 0.5:
                object_counts[class_name] += 1

                # Bounding box
                x1, y1, x2, y2 = map(int, box.xyxy[0])
                cv2.rectangle(frame, (x1, y1), (x2, y2),
                              (0, 255, 0), 2)

                # Label
                cv2.putText(frame,
                            f"{class_name}",
                            (x1, y1 - 5),
                            cv2.FONT_HERSHEY_SIMPLEX,
                            0.5,
                            (255, 0, 0),
                            2)

    # Display counts on video (top-left)
    y_offset = 30
    for obj, cnt in object_counts.items():
        cv2.putText(frame,
                    f"{obj}: {cnt}",
                    (20, y_offset),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.6,
                    (0, 0, 255),
                    2)
        y_offset += 25

    # Show video
    cv2.imshow("Multi-Object Counting", frame)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
