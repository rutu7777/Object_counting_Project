from collections import defaultdict
import cv2
from ultralytics import YOLO

model = YOLO("models/yolov8n.pt")
image = cv2.imread("input/image.webp")

results = model(image, verbose=False)

object_counts = defaultdict(int)

for r in results:
    for box in r.boxes:
        cls = int(box.cls[0])
        conf = float(box.conf[0])
        name = model.names[cls]

        if conf > 0.5:
            object_counts[name] += 1
            x1, y1, x2, y2 = map(int, box.xyxy[0])
            cv2.rectangle(image, (x1, y1), (x2, y2),
                          (0, 255, 0), 2)
            cv2.putText(image, name, (x1, y1 - 5),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5,
                        (255, 0, 0), 2)

# Print results
print("Object counts:")
for obj, cnt in object_counts.items():
    print(f"{obj}: {cnt}")
